
		<footer class="footer-distributed">

 <div class="footer-left">

 <h3>Health<span>CARE</span></h3>

 <p class="footer-links">
 <a href="http://localhost/Online-Hospital-Management-System-master/Home.html">Home</a>
·
 <a href="#">Blog</a>
·
 <a href="#">Pricing</a>
·
 <a href="http://localhost/Online-Hospital-Management-System-master/aboutus.php">About</a>
·
 <a href="#">Faq</a>
·
 <a href="http://localhost/Online-Hospital-Management-System-master/contactus.php">Contact</a>
 </p>

 <p class="footer-company-name">FASTIAN &copy; 2020</p>
 </div>

 <div class="footer-center">

 <div>
 <i class="fa fa-map-marker"></i>
 <p><span>Shah Latif Town</span> Karachi, Pakistan</p>
 </div>

 <div>
 <i class="fa fa-phone"></i>
 <p>+92 300000000</p>
 </div>

 <div>
 <i class="fa fa-envelope"></i>
 <p><a href="mailto:jmshaikh3741">k171234@nu.edu.pk</a></p>
 </div>

 </div>

 <div class="footer-right">

 <p class="footer-company-about">
 <span>Quote</span>
 Kindness is a mark of faith, and whoever has not kindness has not faith.
 </p>
 <h3>HAZRAT MOHAMMAD<span> (SAW)</span></h3>
 <div class="footer-icons">

 <a href="#"><i class="fa fa-facebook"></i></a>
 <a href="#"><i class="fa fa-twitter"></i></a>
 <a href="#"><i class="fa fa-linkedin"></i></a>
 <a href="#"><i class="fa fa-github"></i></a>

 </div>

 </div>

 </footer>

</body>

</html>
